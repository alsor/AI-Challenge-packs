using System;
namespace Ants {
	public enum Tile { Ant, Dead, Land, Food, Water, Unseen, Hill }
}

